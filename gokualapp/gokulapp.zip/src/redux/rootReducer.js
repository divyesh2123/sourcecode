import { combineReducers } from "@reduxjs/toolkit";
import { userReducer } from "./login/reducers";

const rootReducer = combineReducers({
    userReducer: userReducer
});

export default rootReducer;