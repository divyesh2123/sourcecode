import Login from "../pages/Authentication/Login";


const indexRoutes = [
  { path: "/login", component: Login },
 
];

export default indexRoutes;
