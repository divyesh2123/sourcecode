

export default   {

        login : `Account/login`

}