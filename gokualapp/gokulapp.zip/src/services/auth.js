import axios from "axios";

const baseURL = `${process.env.REACT_APP_LOGIN_API_URL}/api`;
const authFetch = axios.create( {
baseURL : baseURL
     
})


  authFetch.interceptors.request.use(
    (request) => {

     if(!request.url.includes("login"))
     {
      let token = JSON.parse(localStorage.getItem("token"));
      request.headers['Authorization'] = `bearer ${token}`
     }
      request.headers['Accept'] = 'application/json';
      request.headers['Content-Type'] = 'application/json';
      request.headers['X-Custom-Header'] = 'header value';
    
      console.log('request sent');
      return request;
    },
    (error) => {
      //to handle or save data in cloud
      return Promise.reject(error);
    }
  );
  
  authFetch.interceptors.response.use(
    (response) => {
      console.log('got response');
      return response;
    },
    (error) => {
      console.log(error.response);
      if (error.response.status === 404) {
        // do something
        console.log('NOT FOUND');
      }
      if (error.response.status === 401) {
        // do something
        console.log('NOT FOUND');
      }
      return Promise.reject(error);
    }
  );
  

export default authFetch;