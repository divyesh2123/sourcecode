export const Brand_DD_REQUEST= 'Brand_DD_REQUEST';
export const Brand_DD_SUCCESS= 'Brand_DD_SUCCESS';
export const Brand_DD_FAILURE= 'Brand_DD_FAILURE';
export const CLEAR_Brand_DD__DATA= 'CLEAR_Brand_DD__DATA';