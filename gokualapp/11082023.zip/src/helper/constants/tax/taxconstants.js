export const Tax_DD_REQUEST= 'Tax_DD_REQUEST';
export const Tax_DD_SUCCESS= 'Tax_DD_SUCCESS';
export const Tax_DD_FAILURE= 'Tax_DD_FAILURE';
export const CLEAR_Tax_DD__DATA= 'CLEAR_Tax_DD__DATA';
