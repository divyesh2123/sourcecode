import React, { useState, useEffect, useMemo } from "react";
import { MantineReactTable } from "mantine-react-table";
import { useDispatch, useSelector } from "react-redux";
import { MantineProvider, useMantineTheme, Box } from "@mantine/core";
import { useNavigate } from "react-router";

import {
  Row,
  Col,
  FormGroup,
  Input,
  FormFeedback,
  Form,
} from "reactstrap";

import * as Yup from "yup";
import Select from "react-select";
import { useFormik, FormikProvider } from "formik";
import { clearDepartmentUpdateData, clearGetDepartmentDataById, departmentUpdateRequest, getDetailDepartmentReq } from "../../redux/department/actions";
import axios from "axios";


const EditDepartMentForm = (props) => {
  console.log("hhhh", props.editID);
  const dispatch = useDispatch();
  const user = JSON.parse(sessionStorage.getItem("user"));
  const [data, setdata] = useState(null);
  const [sortByTax, setsortByTax] = useState(null);
  const [sortByBrand, setsortByBrand] = useState(null);
  const deparmentByIdList = useSelector(
    (state) => state.getDetailDepartmentReducer
  );
  // useEffect for setting edit Id
  useEffect(() => {
    setdata(props.editID);
    try {
      if (props.editID === null) {
        props.setEditID(null);
        dispatch(clearGetDepartmentDataById());
        setdata(null);
        formik.values = formik.initialValues;
      } else {
        GetDataByID();
        fetchTax();
        fetchBrand();
      }
    } catch (error) {}
  }, [props.editID]);

  const [isLoading, setIsLoading] = useState(false);
  // Function to get the data of department by the ID
  const GetDataByID = () => {
    try {
      console.log("Action method 1");
      dispatch(getDetailDepartmentReq(props.editID));
      setIsLoading(true);
    } catch (error) {
      return;
    }
  };

  // Setting the value of the departmentlist from the reducer
  var departmentListReducer1;
  try {
    departmentListReducer1 =
      deparmentByIdList.getDepartmentDetailsData.singleResult;
    console.log("Get Api  Response Api", departmentListReducer1);
  } catch (error) {
    departmentListReducer1 = null;
  }
  //Dropdown
  useEffect(() => {
    // console.log("HDepartment", deparmentByIdList);
    setTaxInisial();
    setBrandInisial();
  }, [deparmentByIdList]);

  const setTaxInisial = () => {
    try {
      if (departmentListReducer1 != null) {
        setIsLoading(false);
        if (departmentListReducer1.department.drdwnGroupTax === 0) {
          setsortByTax(0);
        } else {
          setsortByTax(departmentListReducer1.department.drdwnGroupTax);
        }

       
      }
    } catch (error) {
      return;
    }
  };

 

  const handleSortByTaxChange = (sortBy) => {
    console.log(sortBy);
    setsortByTax(sortBy);
    if (!sortBy === null) {
    }
  };

  const setBrandInisial = () => {
    try {
      if (departmentListReducer1 != null) {
        setIsLoading(false);
        console.log(
          "setBrand",
          departmentListReducer1.departmentSetting.drdwnBrand
        );
        if (departmentListReducer1.departmentSetting.drdwnBrand === 0) {
          setsortByBrand(0);
        } else {
          setsortByBrand(departmentListReducer1.departmentSetting.drdwnBrand);
        }
      }
    } catch (error) {
      return;
    }
  };

  const handleSortByBrandChange = (sortByBrand) => {
    console.log(sortByBrand);
    setsortByBrand(sortByBrand);
  };
  // Formik Validation
  const formik = useFormik({
    // enableReinitialize : use this flag when initial values needs to be changed
    enableReinitialize: true,

    initialValues: {
      departmentname: `${
        departmentListReducer1 === null
          ? ""
          : departmentListReducer1.department.name
      }`,
      departmentcodename: `${
        departmentListReducer1 === null
          ? ""
          : departmentListReducer1.department.code
      }`,

      IsTaxabel: `${
        departmentListReducer1 === null
          ? false
          : departmentListReducer1.department.isTaxable
      }`,
      AddItemInBrand: `${
        departmentListReducer1 === null
          ? false
          : departmentListReducer1.departmentSetting.allowInBrand
      }`,
      DisplayWEB: `${
        departmentListReducer1 === null
          ? false
          : departmentListReducer1.department.displayOnWeb
      }`,
      // ShowInOpenPrice: `${
      //   departmentListReducer1 === null
      //     ? false
      //     : departmentListReducer1.showInOpenPrice
      // }`,
    },
    formikSchema: Yup.object({
      departmentname: Yup.string().required("Please Enter Department Name"),
    }),
    onSubmit: (values) => {
      console.log("values", values);
      //DepartmentSubmit(values);
      DepartmentUpdateSubmit(values);
    },
  });

  const [formformik, setformik] = useState({
    dnm: null,
    dcode: null,
  });

  function handleSubmit(e) {
    console.log("department");
    e.preventDefault();
    const modifiedV = { ...formformik };
    var dnm = document.getElementById("formikTooltip01").value;
    var dcode = document.getElementById("formikTooltip02").value;

    if (dnm === "") {
      modifiedV["dnm"] = false;
    } else {
      modifiedV["dnm"] = true;
    }
    if (dcode === "") {
      modifiedV["dcode"] = false;
    } else {
      modifiedV["dcode"] = true;
    }

    setformik(modifiedV);
  }
  const [sortBy, setsortBy] = useState(null);
  const handlesortByChange = (sortBy) => {
    console.log(sortBy);
    setsortBy(sortBy);
  };
  const DepartmentUpdateSubmit = (values) => {
    console.log("submit");

    dispatch(
      departmentUpdateRequest({
        // id: props.editID,
        // name: values.departmentname,
        // code: values.departmentcodename,
        // allowFoodStamp: JSON.parse(isSubscribed.FoodStamp),
        // isTaxable: JSON.parse(values.IsTaxabel),
        // taxGroupId: `${values.IsTaxabel === false ? 0 : sortByTax.value}`,
        // showInOpenPrice: JSON.parse(isSubscribed.ShowInOpenPrice),
        // priceRatioType: 0,
        // priceRatioValue: values.textratio,
        // ageVerification: JSON.parse(isSubscribed.MinAge),
        // pictureId: 0,
        // modifiedBy: user.userId,
        department: {
          id: props.editID,
          name: values.departmentname,
          code: values.departmentcodename,
          allowFoodStamp: JSON.parse(isSubscribed.FoodStamp),
          isTaxable: JSON.parse(values.IsTaxabel),
          taxGroupId: `${values.IsTaxabel === false ? 0 : sortByTax.value}`,
          showInOpenPrice: JSON.parse(isSubscribed.ShowInOpenPrice),
          priceRatioType: 0,
          priceRatioValue: values.textratio,
          ageVerification: JSON.parse(isSubscribed.MinAge),
          pictureId: 0,
          displayOnWeb: JSON.parse(isSubscribed.DisplayWEB),
          modifiedBy: user.userId,
        },
        departmentSetting: {
          departmentId: props.editID,
          allowInBrand: JSON.parse(values.AddItemInBrand),
          brandId: `${values.AddItemInBrand === false ? 0 : sortByBrand.value}`,
          isNonRevenue: JSON.parse(isSubscribed.MakeItemNonRevenue),
          nonDiscountable: JSON.parse(isSubscribed.MakeItemNonDiscountable),
          nonStock: JSON.parse(isSubscribed.MakeItemNonStock),
          nonCountable: JSON.parse(isSubscribed.MakeItemNoncountable),
          weightItemFlag: JSON.parse(isSubscribed.EnableWeightItemFlag),
          allowWiccheck: JSON.parse(isSubscribed.EnableWICCheckAllowance),
          webItemFlag: JSON.parse(isSubscribed.EnableWebItemFlag),
          isFoodStamp: JSON.parse(isSubscribed.EnableFoodStampAllowance),
        },
      })
    );
    document.getElementById("addmodalpopup").click();
  };

  const [tax, setTax] = useState([{ label: "Please Select", value: "" }]);
  // const [brand, setBrand] = useState([{ label: "Please Select", value: "" }]);

  const fetchTax = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_PRODUCT_API_URL}/api/group/dropdown/tax/1`
      );
      setTax(response.data.listResult);
      console.log("editdrop", tax);
    } catch (error) {
      console.error("Error fetching tax:", error);
    }
  };
  const handleTaxChange = (selectedYear) => {
    console.log(selectedYear);
    setsortBy(selectedYear);
  };
  const [brand, setBrand] = useState([{ label: "Please Select", value: "" }]);
  const fetchBrand = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_PRODUCT_API_URL}/api/brand/dropdown/1`
      );
      setBrand(response.data.listResult);
      console.log("editdrop", brand);
    } catch (error) {
      console.error("Error fetching brand:", error);
    }
  };
  const handleBrandChange = (selectedBrand) => {
    console.log(selectedBrand);
    setsortBy(selectedBrand);
  };
  const updateDepartment = useSelector(
    (state) => state.updateDepartmentReducer
  );
  // update existing Department useEffect data here
  useEffect(() => {
    if (
      updateDepartment.updateDepartmentData === null &&
      updateDepartment.error === null
    ) {
      return;
    } else if (
      updateDepartment.updateDepartmentData !== null &&
      updateDepartment.error === null
    ) {
      setTimeout(() => {
        dispatch(clearDepartmentUpdateData());
      }, 2000);
      if (updateDepartment.updateDepartmentData.status === 200) {
        props.showsAlert(
          "sucess",
          "Department Updated successfully.",
          "success"
        );
        // close the pop up here
        // setIsLoading(false);
        // setdata(null);
        document.getElementById("EditModelClose").click();
      } else {
        //setIsLoading(false);
        props.showsAlert(
          "warning",
          "There occured some error while adding New Department." +
            " " +
            // "ref : " +
            // updateDepartment.updateDepartmentData.result +
            " " +
            updateDepartment.updateDepartmentData.message,
          "warning"
        );
      }
    } else {
      setTimeout(() => {
        dispatch(clearDepartmentUpdateData());
      }, 2000);

      //setIsLoading(false);
      props.showsAlert("warning", updateDepartment.error.message, "warning");
    }
  }, [updateDepartment]);

  const [checkboxChecked, setCheckboxChecked] = useState(false);

  const handleCheckboxChange = (event) => {
    setCheckboxChecked(event.target.checked);
    formik.setFieldValue("IsTaxabel", event.target.checked);
    // Disable or enable dropdown based on checkbox state
    formik.setFieldValue("taxgroup1", "");
  };

  // checkbox check functions here
  const handleChangeCheckBox = (event) => {
    //    event.preventDefault();
    setIsSubscribed({
      ...isSubscribed,
      [event.target.name]: event.target.checked,
    });
  };

  //brand check box disable
  const [checkboxChecked2, setCheckboxChecked2] = useState(false);

  const handleCheckboxChange2 = (event) => {
    setCheckboxChecked2(event.target.checked);
    formik.setFieldValue("AddItemInBrand", event.target.checked);
    // Disable or enable dropdown based on checkbox state
    formik.setFieldValue("barndgroup", "");
  };

  // checkbox check functions here
  // const handleChangeCheckBox2 = (event) => {
  //   //    event.preventDefault();
  //   setIsSubscribed({
  //     ...isSubscribed,
  //     [event.target.name]: event.target.checked,
  //   });
  // };

  // checkbox data set while brandlist state changes
  useEffect(() => {
    setIsSubscribed({
      FoodStamp: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.department.allowFoodStamp
      }`,
      MinAge: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.department.ageVerification
      }`,
      ShowInOpenPrice: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.department.showInOpenPrice
      }`,
      DisplayWEB: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.department.displayOnWeb
      }`,
      MakeItemNonStock: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.nonStock
      }`,
      EnableWebItemFlag: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.webItemFlag
      }`,
      EnableWICCheckAllowance: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.allowWiccheck
      }`,
      MakeItemNonRevenue: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.isNonRevenue
      }`,
      EnableFoodStampAllowance: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.isFoodStamp
      }`,
      EnableWeightItemFlag: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.weightItemFlag
      }`,
      MakeItemNoncountable: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.nonCountable
      }`,
      MakeItemNonDiscountable: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.nonDiscountable
      }`,
      AddItemInBrand: `${
        departmentListReducer1 === null
          ? "false"
          : departmentListReducer1.departmentSetting.allowInBrand
      }`,
    });
  }, [departmentListReducer1]);

  // State for checkboxes declared here
  const [isSubscribed, setIsSubscribed] = useState({
    FoodStamp: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.department.allowFoodStamp
    }`,
    MinAge: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.department.ageVerification
    }`,
    ShowInOpenPrice: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.department.showInOpenPrice
    }`,
    DisplayWEB: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.department.displayOnWeb
    }`,
    MakeItemNonStock: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.nonStock
    }`,
    EnableWebItemFlag: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.webItemFlag
    }`,
    EnableWICCheckAllowance: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.allowWiccheck
    }`,
    MakeItemNonRevenue: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.isNonRevenue
    }`,
    EnableFoodStampAllowance: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.isFoodStamp
    }`,
    EnableWeightItemFlag: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.weightItemFlag
    }`,
    MakeItemNoncountable: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.nonCountable
    }`,
    MakeItemNonDiscountable: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.nonDiscountable
    }`,
    AddItemInBrand: `${
      departmentListReducer1 === null
        ? "false"
        : departmentListReducer1.departmentSetting.allowInBrand
    }`,
  });

  return (
    <div>
      <FormikProvider value={formik}>
        <div
          className="modal fade"
          id="editDepartmentModal1"
          tabIndex={-1}
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
          data-bs-backdrop="static"
          data-bs-keyboard="false"
        >
          <div className="modal-dialog modal-md modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header p-3 pb-2">
                <h5 className="text-center text-light">
                  Edit Department Information
                </h5>
              </div>
              <Form
                className="tablelist-form needs-formik"
                autoComplete="off"
                onSubmit={(e) => {
                  e.preventDefault();
                  formik.handleSubmit();
                  return false;
                }}
              >
                <div className="modal-body p-4">
                  <Row>
                    <Col md="12">
                      <FormGroup className="mb-0">
                        <label htmlFor="departmentname" className="text-dark">
                          Department Name
                        </label>
                        <Input
                          name="departmentname"
                          // placeholder="Department Name"
                          type="text"
                          className="form-control"
                          style={{ background: "#f5f5dc" }}
                          id="departmentname"
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          value={formik.values.departmentname || ""}
                          invalid={
                            !!(
                              formik.touched.departmentname &&
                              formik.errors.departmentname
                            )
                          }
                        />
                        {formik.touched.departmentname &&
                        formik.errors.departmentname ? (
                          <FormFeedback type="invalid">
                            {formik.errors.departmentname}
                          </FormFeedback>
                        ) : null}
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col md="12">
                      <FormGroup className="mb-0">
                        <label htmlFor="departmentname" className="text-dark">
                          Department Code
                        </label>
                        <Input
                          name="departmentcodename"
                          // placeholder="Department Code"
                          type="text"
                          className="form-control"
                          id="departmentcodename"
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                          value={formik.values.departmentcodename || ""}
                          invalid={
                            !!(
                              formik.touched.departmentcodename &&
                              formik.errors.departmentcodename
                            )
                          }
                        />
                        {formik.touched.departmentcodename &&
                        formik.errors.departmentcodename ? (
                          <FormFeedback type="invalid">
                            {formik.errors.departmentcodename}
                          </FormFeedback>
                        ) : null}
                      </FormGroup>
                    </Col>
                  </Row>{" "}
                  <Row>
                    <Col md="6">
                      <Row>
                        <FormGroup>
                          {/* <input
                            className="form-check-input"
                            type="checkbox"
                            id="FoodStamp"
                            name="FoodStamp"
                            onChange={formik.handleChange}
                            value={formik.values.FoodStamp}
                          /> */}
                          {data ? (
                            isSubscribed.FoodStamp === "true" ? (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="FoodStamp"
                                name="FoodStamp"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.FoodStamp}
                                checked
                              />
                            ) : (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="FoodStamp"
                                name="FoodStamp"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.FoodStamp}
                              />
                            )
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="FoodStamp"
                              name="FoodStamp"
                              onChange={handleChangeCheckBox}
                              value={JSON.parse(isSubscribed.FoodStamp)}
                            />
                          )}

                          <label
                            className="form-check-label text-dark ms-3 mt-1"
                            htmlFor="FoodStamp"
                          >
                            Allow Food Stamp
                          </label>
                        </FormGroup>
                      </Row>
                      <Row>
                        <FormGroup>
                          {data ? (
                            isSubscribed.MinAge === "true" ? (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="MinAge"
                                name="MinAge"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.MinAge}
                                checked
                              />
                            ) : (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="MinAge"
                                name="MinAge"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.MinAge}
                              />
                            )
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MinAge"
                              name="MinAge"
                              onChange={handleChangeCheckBox}
                              value={JSON.parse(isSubscribed.MinAge)}
                            />
                          )}

                          <label
                            className="form-check-label text-dark ms-3 mt-1"
                            htmlFor="MinAge"
                          >
                            Min. Age
                          </label>
                        </FormGroup>
                      </Row>
                      <Row>
                        <FormGroup>
                          {data ? (
                            formik.values.IsTaxabel === "true" ? (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="IsTaxabel"
                                name="IsTaxabel"
                                onChange={formik.handleChange}
                                value={formik.values.IsTaxabel}
                                checked={formik.values.IsTaxabel}
                              />
                            ) : (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="IsTaxabel"
                                name="IsTaxabel"
                                // onChange={formik.handleChange}
                                value={formik.values.IsTaxabel}
                                onChange={handleCheckboxChange}

                                //onRateChange={formik.handleChange}
                                //  value={formik.values.IsTaxabel}
                              />
                            )
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="IsTaxabel"
                              name="IsTaxabel"
                              onChange={formik.handleChange}
                              value={JSON.parse(formik.values.IsTaxabel)}
                            />
                          )}

                          <label
                            className="form-check-label text-dark ms-3 mt-1"
                            htmlFor="IsTaxabel"
                          >
                            Is Taxable
                          </label>
                        </FormGroup>
                      </Row>
                    </Col>

                    <Col md="6">
                      <Row>
                        <FormGroup>
                          {data ? (
                            isSubscribed.ShowInOpenPrice === "true" ? (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="ShowInOpenPrice"
                                name="ShowInOpenPrice"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.ShowInOpenPrice}
                                checked
                              />
                            ) : (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="ShowInOpenPrice"
                                name="ShowInOpenPrice"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.ShowInOpenPrice}
                              />
                            )
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="ShowInOpenPrice"
                              name="ShowInOpenPrice"
                              onChange={handleChangeCheckBox}
                              value={JSON.parse(isSubscribed.ShowInOpenPrice)}
                            />
                          )}

                          <label
                            className="form-check-label text-dark ms-3 mt-1"
                            htmlFor="ShowInOpenPrice"
                          >
                            Show In Open Price
                          </label>
                        </FormGroup>
                      </Row>
                      <Row>
                        <FormGroup>
                          {data ? (
                            isSubscribed.DisplayWEB === "true" ? (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="DisplayWEB"
                                name="DisplayWEB"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.DisplayWEB}
                                checked
                              />
                            ) : (
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="DisplayWEB"
                                name="DisplayWEB"
                                onChange={handleChangeCheckBox}
                                value={isSubscribed.DisplayWEB}
                              />
                            )
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="DisplayWEB"
                              name="DisplayWEB"
                              onChange={handleChangeCheckBox}
                              value={JSON.parse(isSubscribed.DisplayWEB)}
                            />
                          )}

                          <label
                            className="form-check-label text-dark ms-3 mt-1"
                            htmlFor="DisplayOnWeb"
                          >
                            Display On Web
                          </label>
                        </FormGroup>
                      </Row>
                      <Row>
                        {/* <Col md="12"> */}
                        <FormGroup className="mb-0">
                          {/* <label htmlFor="taxgroup1" className="text text-dark">
                            Tax
                          </label> */}

                          <Select
                            value={sortByTax}
                            onChange={(e) => {
                              handleSortByTaxChange(e);
                              setsortByTax(e);
                            }}
                            options={tax}
                            id="taxgroup1"
                            className="js-example-basic-single mb-0 text-dark"
                            name="taxgroup1"
                            // disabled={!checkboxChecked}
                            isDisabled={
                              formik.values.IsTaxabel === "false" ||
                              !formik.values.IsTaxabel
                            }
                            // isDisabled={sortByTax === 0}
                          />
                        </FormGroup>
                        {/* </Col> */}
                      </Row>
                    </Col>
                  </Row>
                  <Row></Row>{" "}
                  {/* ############################################department setting#######################################################*/}
                  <div className="mt-1 text-gokul-blue">
                    <p>Settings</p>
                  </div>
                  <Row>
                    <Col>
                     
                      {data ? (
                        isSubscribed.MakeItemNonStock === "true" ? (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="MakeItemNonStock"
                            name="MakeItemNonStock"
                            onChange={handleChangeCheckBox}
                            value={isSubscribed.MakeItemNonStock}
                            checked
                          />
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="MakeItemNonStock"
                            name="MakeItemNonStock"
                            onChange={handleChangeCheckBox}
                            value={isSubscribed.MakeItemNonStock}
                          />
                        )
                      ) : (
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id="MakeItemNonStock"
                          name="MakeItemNonStock"
                          onChange={handleChangeCheckBox}
                          value={JSON.parse(isSubscribed.MakeItemNonStock)}
                        />
                      )}

                      <label
                        className="form-check-label text-dark ms-3 mt-1"
                        htmlFor="MakeItemNonStock"
                      >
                        Make Item Non-Stock
                      </label>
                    </Col>
                    <Col>
                      <FormGroup>
                       
                        {data ? (
                          isSubscribed.EnableWebItemFlag === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableWebItemFlag"
                              name="EnableWebItemFlag"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableWebItemFlag}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableWebItemFlag"
                              name="EnableWebItemFlag"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableWebItemFlag}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="EnableWebItemFlag"
                            name="EnableWebItemFlag"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(isSubscribed.EnableWebItemFlag)}
                          />
                        )}

                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="EnableWebItemFlag"
                        >
                          Enable Web-Item Flag
                        </label>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <FormGroup>
                       
                        {data ? (
                          isSubscribed.EnableWICCheckAllowance === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableWICCheckAllowance"
                              name="EnableWICCheckAllowance"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableWICCheckAllowance}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableWICCheckAllowance"
                              name="EnableWICCheckAllowance"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableWICCheckAllowance}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="EnableWICCheckAllowance"
                            name="EnableWICCheckAllowance"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(
                              isSubscribed.EnableWICCheckAllowance
                            )}
                          />
                        )}
                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="EnableWICCheckAllowance"
                        >
                          Enable WIC Check Allowance
                        </label>
                      </FormGroup>
                    </Col>
                    <Col>
                      <FormGroup>
                        {data ? (
                          isSubscribed.MakeItemNonDiscountable === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MakeItemNonDiscountable"
                              name="MakeItemNonDiscountable"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.MakeItemNonDiscountable}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MakeItemNonDiscountable"
                              name="MakeItemNonDiscountable"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.MakeItemNonDiscountable}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="MakeItemNonDiscountable"
                            name="MakeItemNonDiscountable"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(
                              isSubscribed.MakeItemNonDiscountable
                            )}
                          />
                        )}
                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="MakeItemNonDiscountable"
                        >
                          Make Item Non-Discountable
                        </label>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <FormGroup>
                       
                        {data ? (
                          isSubscribed.MakeItemNoncountable === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MakeItemNoncountable"
                              name="MakeItemNoncountable"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.MakeItemNoncountable}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MakeItemNoncountable"
                              name="MakeItemNoncountable"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.MakeItemNoncountable}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="MakeItemNoncountable"
                            name="MakeItemNoncountable"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(
                              isSubscribed.MakeItemNoncountable
                            )}
                          />
                        )}
                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="MakeItemNoncountable"
                        >
                          Make Item Non-Countable
                        </label>
                      </FormGroup>
                    </Col>
                    <Col>
                      <FormGroup>
                      
                        {data ? (
                          isSubscribed.EnableWeightItemFlag === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableWeightItemFlag"
                              name="EnableWeightItemFlag"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableWeightItemFlag}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableWeightItemFlag"
                              name="EnableWeightItemFlag"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableWeightItemFlag}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="EnableWeightItemFlag"
                            name="EnableWeightItemFlag"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(
                              isSubscribed.EnableWeightItemFlag
                            )}
                          />
                        )}
                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="EnableWeightItemFlag"
                        >
                          Enable Weight Item Flag
                        </label>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <FormGroup>
                       
                        {data ? (
                          isSubscribed.EnableFoodStampAllowance === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableFoodStampAllowance"
                              name="EnableFoodStampAllowance"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableFoodStampAllowance}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="EnableFoodStampAllowance"
                              name="EnableFoodStampAllowance"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.EnableFoodStampAllowance}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="EnableFoodStampAllowance"
                            name="EnableFoodStampAllowance"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(
                              isSubscribed.EnableFoodStampAllowance
                            )}
                          />
                        )}
                        <label
                          className="form-check-label text-dark ms-2 mt-1"
                          htmlFor="EnableFoodStampAllowance"
                        >
                          Enable FoodStamp Allowance
                        </label>
                      </FormGroup>
                    </Col>
                    <Col>
                      <FormGroup>
                       
                        {data ? (
                          isSubscribed.MakeItemNonRevenue === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MakeItemNonRevenue"
                              name="MakeItemNonRevenue"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.MakeItemNonRevenue}
                              checked
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="MakeItemNonRevenue"
                              name="MakeItemNonRevenue"
                              onChange={handleChangeCheckBox}
                              value={isSubscribed.MakeItemNonRevenue}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="MakeItemNonRevenue"
                            name="MakeItemNonRevenue"
                            onChange={handleChangeCheckBox}
                            value={JSON.parse(isSubscribed.MakeItemNonRevenue)}
                          />
                        )}
                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="MakeItemNonRevenue"
                        >
                          Make Item Non-Revenue
                        </label>
                      </FormGroup>
                    </Col>
                  </Row>
                  <Row>
                    <Col>
                      <FormGroup>
                       

                        {data ? (
                          formik.values.AddItemInBrand === "true" ? (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="AddItemInBrand"
                              name="AddItemInBrand"
                              onChange={formik.handleChange}
                              value={formik.values.AddItemInBrand}
                              checked={formik.values.AddItemInBrand}
                            />
                          ) : (
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="AddItemInBrand"
                              name="AddItemInBrand"
                              // onChange={formik.handleChange}
                              value={formik.values.AddItemInBrand}
                              onChange={handleCheckboxChange2}

                              //onRateChange={formik.handleChange}
                              //  value={formik.values.IsTaxabel}
                            />
                          )
                        ) : (
                          <input
                            className="form-check-input"
                            type="checkbox"
                            id="AddItemInBrand"
                            name="AddItemInBrand"
                            onChange={formik.handleChange}
                            value={JSON.parse(formik.values.AddItemInBrand)}
                          />
                        )}

                        <label
                          className="form-check-label text-dark ms-3 mt-1"
                          htmlFor="AddItemInBrand"
                        >
                          Add Item In Brand
                        </label>
                      </FormGroup>
                    </Col>

                    <Col>
                      <FormGroup className="mb-0">
                        {/* <label htmlFor="taxgroup1" className="text text-dark">
                            Tax
                          </label> */}

                        <Select
                          value={sortByBrand}
                          onChange={(e) => {
                            handleSortByBrandChange(e);
                            // setsortByBrand(e);
                          }}
                          options={brand}
                          id="barndgroup"
                          className="js-example-basic-single mb-0 text-dark"
                          name="barndgroup"
                          isDisabled={
                            formik.values.AddItemInBrand === "false" ||
                            !formik.values.AddItemInBrand
                          }
                          
                        />
                      </FormGroup>
                      
                    </Col>
                  </Row>
                </div>

                <div className="modal-footer center-footer-modal ">
                  <div className="hstack gap-2 d-flex justify-content-center">
                    <button
                      type="submit"
                      className="btn custom-Green add-btn "

                      // id="add-btn"
                    >
                      Save
                    </button>
                    <button
                     
                      className="btn add-btn custom-Red"
                      data-bs-dismiss="modal"
                      id="EditModelClose"
                      type="reset"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </div>
      </FormikProvider>
    </div>
  );
};

export default EditDepartMentForm;
